package com.sachin.aiassistant.dto;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
public record RegisterRequest(@NotBlank @Size(max=150) String organizationName,
                              @NotBlank @Size(max=120) String fullName,
                              @NotBlank @Email @Size(max=180) String email,
                              @NotBlank @Size(min=8,max=72) String password) {}
